import React from 'react';
import {
  AlertTriangle,
  Bot,
  HelpCircle,
  Import,
  LayoutPanelLeft,
  Moon,
  RotateCcw,
  RotateCw,
  Settings2,
  Sun,
  ZoomIn,
  ZoomOut
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Chip } from '../ui/Chip';
import { Menu } from '../ui/Menu';

type TopBarProps = {
  isDarkMode: boolean;
  nodesCount: number;
  edgesCount: number;
  backupStatusText: string;
  hasRecoverySnapshot: boolean;
  recoveryLastSavedAt: string | null;
  feedbackHref: string;
  storageWarning: string | null;
  isSidebarOpen: boolean;
  isInspectorOpen: boolean;
  canUndo: boolean;
  canRedo: boolean;
  isAIEnabled: boolean;
  isAILoading: boolean;
  onToggleSidebar: () => void;
  onToggleInspector: () => void;
  onToggleTheme: () => void;
  onOpenHelp: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onOpenCanvasControls: () => void;
  onOpenAiLauncher: () => void;
  onRestoreRecovery: () => void;
  onResetCanvas: () => void;
  onImportDiagram: () => void;
  onExportDiagram: () => void;
  onExportSvg: () => void;
  onExportPng: () => void;
  onExportPdf: () => void;
};

const TopBar: React.FC<TopBarProps> = ({
  isDarkMode,
  nodesCount,
  edgesCount,
  backupStatusText,
  hasRecoverySnapshot,
  recoveryLastSavedAt,
  feedbackHref,
  storageWarning,
  isSidebarOpen,
  isInspectorOpen,
  canUndo,
  canRedo,
  isAIEnabled,
  isAILoading,
  onToggleSidebar,
  onToggleInspector,
  onToggleTheme,
  onOpenHelp,
  onUndo,
  onRedo,
  onZoomIn,
  onZoomOut,
  onOpenCanvasControls,
  onOpenAiLauncher,
  onRestoreRecovery,
  onResetCanvas,
  onImportDiagram,
  onExportDiagram,
  onExportSvg,
  onExportPng,
  onExportPdf
}) => {
  const exportItems = [
    { type: 'title' as const, label: 'Export' },
    { label: 'Export JSON', onSelect: onExportDiagram },
    { label: 'Export SVG', onSelect: onExportSvg },
    { label: 'Export PNG', onSelect: onExportPng },
    { label: 'Export PDF', onSelect: onExportPdf }
  ];

  const moreItems = [
    { type: 'title' as const, label: 'Workspace' },
    {
      label: hasRecoverySnapshot ? 'Restore recovery snapshot' : 'No recovery snapshot',
      onSelect: onRestoreRecovery,
      disabled: !hasRecoverySnapshot
    },
    { label: 'Import JSON', onSelect: onImportDiagram },
    { type: 'sep' as const },
    { label: 'Canvas controls', onSelect: onOpenCanvasControls },
    { label: 'Reset canvas', onSelect: onResetCanvas },
    { type: 'sep' as const },
    { type: 'title' as const, label: 'Support' },
    { label: 'Help', onSelect: onOpenHelp },
    {
      label: 'Feedback',
      onSelect: () => window.open(feedbackHref, '_blank', 'noopener,noreferrer')
    }
  ];

  const aiItems = [
    { type: 'title' as const, label: 'AI' },
    {
      label: isAIEnabled ? 'Open AI launcher' : 'AI disabled for MVP',
      onSelect: onOpenAiLauncher,
      disabled: !isAIEnabled || isAILoading
    }
  ];

  return (
    <div className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur dark:border-slate-800 dark:bg-slate-950/70">
      <div className="flex items-center justify-between px-3 py-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900 text-white dark:bg-white dark:text-slate-900">
              FF
            </div>
            <div className="leading-tight">
              <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Flow of Funds Studio
              </div>
              <div className="text-xs text-slate-500">
                {nodesCount} nodes • {edgesCount} edges
              </div>
            </div>
          </div>

          <div className="hidden items-center gap-2 md:flex">
            <Chip tone={storageWarning ? 'warn' : 'good'}>{storageWarning ? 'Autosave issue' : backupStatusText}</Chip>
            {!isAIEnabled ? <Chip>AI off</Chip> : null}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={onToggleSidebar} title="Toggle library">
            <LayoutPanelLeft size={16} className="mr-1 opacity-80" />
            {isSidebarOpen ? 'Library on' : 'Library off'}
          </Button>

          <Button size="sm" variant="ghost" onClick={onToggleInspector} title="Toggle inspector">
            <Settings2 size={16} className="mr-1 opacity-80" />
            {isInspectorOpen ? 'Inspect on' : 'Inspect off'}
          </Button>

          <Button size="sm" variant="ghost" onClick={onUndo} disabled={!canUndo} title="Undo">
            <RotateCcw size={16} className="mr-1 opacity-80" />
            Undo
          </Button>

          <Button size="sm" variant="ghost" onClick={onRedo} disabled={!canRedo} title="Redo">
            <RotateCw size={16} className="mr-1 opacity-80" />
            Redo
          </Button>

          <Button size="sm" variant="ghost" onClick={onZoomOut} title="Zoom out">
            <ZoomOut size={16} className="mr-1 opacity-80" />
            Zoom
          </Button>

          <Button size="sm" variant="ghost" onClick={onZoomIn} title="Zoom in">
            <ZoomIn size={16} className="opacity-80" />
          </Button>

          <Menu
            align="right"
            trigger={
              <Button size="sm" variant="secondary">
                Export
              </Button>
            }
            items={exportItems}
          />

          <Button size="sm" variant="ghost" onClick={onToggleTheme} title="Toggle theme">
            {isDarkMode ? <Sun size={16} className="mr-1 opacity-80" /> : <Moon size={16} className="mr-1 opacity-80" />}
            {isDarkMode ? 'Light' : 'Dark'}
          </Button>

          <Menu
            align="right"
            trigger={
              <Button size="sm" variant="secondary">
                More
              </Button>
            }
            items={[...aiItems, { type: 'sep' as const }, ...moreItems]}
          />
        </div>
      </div>

      {hasRecoverySnapshot && recoveryLastSavedAt ? (
        <div className="px-3 pb-2 text-xs text-slate-500">
          Recovery saved {recoveryLastSavedAt}
        </div>
      ) : null}

      {!isAIEnabled ? (
        <div className="px-3 pb-2 text-xs text-slate-500">
          AI disabled for MVP
        </div>
      ) : null}

      {storageWarning ? (
        <div className="px-3 pb-2 text-xs text-amber-700 dark:text-amber-200">
          <AlertTriangle size={14} className="mr-1 inline-block align-[-2px]" />
          {storageWarning}
        </div>
      ) : null}
    </div>
  );
};

export default TopBar;
