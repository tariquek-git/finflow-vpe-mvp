# FinFlow MVP UI Patch

This patch adds a small UI kit and refactors TopBar and Sidebar to a cleaner modern layout.

## Files included
- components/ui/cn.ts (new)
- components/ui/Button.tsx (new)
- components/ui/Chip.tsx (new)
- components/ui/Menu.tsx (new)
- components/layout/TopBar.tsx (updated)
- components/Sidebar.tsx (updated)

## How to apply (manual)
1. Copy the files into your repo, preserving paths.
2. Run `npm install` (no new deps).
3. Run `npm run dev`
4. Run `npm run test:smoke` and `npm run test:mvp`

## Notes
- TopBar keeps the same props contract and remains a default export.
- Sidebar search input styling is updated and the placeholder is more product oriented.
